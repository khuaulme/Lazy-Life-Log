"use strict";
var https = require('https');

// Parameters of the lambda function explained here
// http://docs.aws.amazon.com/lambda/latest/dg/nodejs-prog-model-handler.html
exports.handler = (event, context, callback) => {
    try {
        if (event.session.new) {
            console.log("NEW SESSION");
            onSessionStarted(event.request.requestId);
        }

        switch (event.request.type) {
            case "LaunchRequest":
                console.log("LAUNCH REQUEST");
                onLaunch(event.request.requestId, callback);
                break;
            case "IntentRequest":
                console.log("INTENT REQUEST");
                onIntent(event.request, callback)
                break;
            case "SessionEndedRequest":
                onSessionEnded(event.request.requestId);
                console.log("SESSION END REQUEST");
                break;
            default:
                context.fail("INVALID REQUEST TYPE:" + event.request.type);
        }
    } catch (error) {
        context.fail("Exception: " + error)
    }
}

function onSessionStarted(requestId) {
    console.log("In function onSessionStarted" + requestId);
}

function onSessionEnded(requestId) {
    console.log('In function onSessionEnded: ' + requestId);
}

function onLaunch(requestId, callback) {
    console.log("In function onLaunch: " + requestId);
    handleWelcomeResponse(callback);
}

function onIntent(request, callback) {
    console.log("In function onIntent : TOSTART");
    const intentName = request.intent.name;
    console.log("In function onIntent : " + intentName);

    if (intentName === 'AMAZON.HelpIntent') {
        console.log("AMAZON.HelpIntent");
        handleWelcomeResponse(callback);
    } else if (intentName === 'AMAZON.StopIntent' || intentName === 'AMAZON.CancelIntent') {
        console.log("AMAZON.StopIntent");
        handleGoodbyeResponse(callback);
    } else if (intentName === 'GetDrinkServings') {
        console.log("Calling the GET DRINK SERVINGS intent");
        getDrinkServings(request, callback);
    } else if (intentName === 'GetCalories') {
        console.log("Calling the GET CALORIES intent");
        getCalories(request, callback);
    } else {
        throw new Error("Could not identify indent: " + intentName);
    }
}

function getCalories(request, callback){
    console.log("In GETCALORIES function");
    fillSlots(request, callback);       // MAKE SURE ALL SLOTS HAVE BEEN FILLED
    var slots = request.intent.slots;
    var drinkName = slots.DrinkName.value;
    console.log("Drink Name: " + drinkName);

    var timeFrame = slots.TimeFrame.value;
    console.log("Time Frame: " + timeFrame);
    console.log("All slots have been filled");

    var index = 0;
    var numCalories = 0; // if array is empty
    var miles = 0;
    var speech = "You don't owe me a thing. Take the day off";

    var pathStarter = 'https://whispering-earth-61603.herokuapp.com/';
    var pathEnder = "";
    var fullPath;

    if ((drinkName === 'alcohol') || (drinkName === 'water') || (drinkName === 'healthy') || (drinkName ==='caffeine') || (drinkName === 'other')) {
        pathEnder = drinkName + '/Alexa';
    } else {
        pathEnder = "drinks/" + drinkName + '/Alexa';
    }
    fullPath = pathStarter + pathEnder;
    console.log("!!!FULL PATH!!! : " + fullPath);

    var req = https.get(fullPath, function (response) {
        var json = "";
        response.on('data', function (chunk) {
            json += chunk;
        });                     // end function .on
        response.on('end', function () {
            var jsonData = JSON.parse(json);
            console.log("jsonData length is: " + jsonData.length);

            if (jsonData.length > 0) {
                if (timeFrame === "today") {
                    for (index = 0; index < jsonData.length; index++) {
                        numCalories = numCalories + (jsonData[index].dservings * jsonData[index].calories);
                    }
                } else {  // timeFrame === this week
                    for (index = 0; index < jsonData.length; index++) {
                        numCalories = numCalories + (jsonData[index].wservings * jsonData[index].calories);
                    }
                }
                miles = numCalories / 80;
            }

            speech = "You have consumed " + numCalories + " because of " + drinkName + ". That is " + miles +" miles." +
                " Or " + numCalories/5 + " minutes of push-ups.";
            console.log("GET CALORIES SPEECH: " + speech);

            const speechletResponse = buildSpeechletResponse("Calories", speech, null, false);
            callback(null, generateResponse(speechletResponse, {}));
        });
    });
}

function getDrinkServings(request, callback) {
    console.log("In GETDRINKSERVINGS function");
    fillSlots(request, callback);       // MAKE SURE ALL SLOTS HAVE BEEN FILLED
    var slots = request.intent.slots;
    var drinkName = slots.DrinkName.value;
    console.log("Drink Name: " + drinkName);

    var timeFrame = slots.TimeFrame.value;
    console.log("Time Frame: " + timeFrame);
    console.log("All slots have been filled");

    getDrinkInfo(drinkName, timeFrame, callback);
}

function fillSlots(request, callback) {
    console.log('Dialog state: ' + request.dialogState);
    console.log('Intent: ' + request.intent);
    if (request.dialogState !== "COMPLETED") {
        console.log('Dialog.Delegate directive to prompt for more info');
        const speechletResponse = {
            outputSpeech: null,
            card: null,
            reprompt: null,
            shouldEndSession: false,
            directives: [{
                type: "Dialog.Delegate"      // this means Alexa should continue dialog as it sees fit
            }]
        };
        callback(null, generateResponse(speechletResponse, {}));
    }
}

function getDrinkInfo(drinkName, timeFrame, callback) {
    console.log("In function GETDRINKINFO. drinkName: " + drinkName);

    var pathStarter = 'https://whispering-earth-61603.herokuapp.com/';
    var pathEnder = "";
    var fullPath;

    if ((drinkName === 'alcohol') || (drinkName === 'water') || (drinkName === 'healthy') || (drinkName ==='caffeine') || (drinkName === 'other')) {
        pathEnder = drinkName + '/Alexa';
    } else {
        pathEnder = "drinks/" + drinkName + '/Alexa';
    }
    fullPath = pathStarter + pathEnder;
    console.log("!!!FULL PATH!!! : " + fullPath);

    var request = https.get(fullPath, function (response) {
        var json = "";
        response.on('data', function (chunk) {
            json += chunk;
        });                     // end function .on
        response.on('end', function () {
            var jsonData = JSON.parse(json);
            console.log("jsonData length is: " + jsonData.length);
            var numServings = 0; // if array is empty
            var qtyString = "servings";
            var i = 0;

            if (jsonData.length > 0) {
                console.log("dservings is : " + jsonData[0].dservings);
                console.log("Week Servings is : " +jsonData[0].wservings);

            }
            if (timeFrame === "today"){
                for (i = 0; i < jsonData.length; i ++) {
                    numServings = numServings + jsonData[i].dservings;
                }
            } else  {  // timeFrame === this week
                for (i = 0; i < jsonData.length; i ++) {
                    numServings = numServings + jsonData[i].wservings;
                }
            }
            if (numServings === 1) { qtyString = "serving";}


            const speech = "You have had " + numServings + "  " + qtyString + " of " + drinkName + " " + timeFrame;

            console.log(speech);

            const speechletResponse = buildSpeechletResponse("Answer", speech, null, false);
            callback(null, generateResponse(speechletResponse, {}));
        });
    });
}

// Invoked by the session launch as well as the help intent
function handleWelcomeResponse(callback) {
    console.log('In function handleWelcomeResponse');
    const title = "Welcome";

    const speechOutput = "Welcome to my lazy life log. Ask me about your drink consumption, and I'll help you make good choices without shaming you at all.";
    var repromptText = "I'm sorry I didn't catch that. Huh? ";

    var speechletResponse = buildSpeechletResponse(title, speechOutput, repromptText, false);
    callback(null, generateResponse(speechletResponse, {}));
}

function handleGoodbyeResponse(callback) {
    console.log("In function handleGoodbyeResponse");
    var speechOutput = "Thank you for using my lazy life log. Make good choices to hydrate and prosper!";
    var speechletResponse = buildSpeechletResponse("Goodbye", speechOutput, null, true);
    callback(null, generateResponse(speechletResponse, {}));
}

function buildSpeechletResponse(title, outputText, repromptText, shouldEndSession) {
    return {
        outputSpeech: {
            type: "PlainText",
            text: outputText
        },
        card: {
            type: "Simple",
            title: "Lazy Life Log",
            content: outputText
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: repromptText
            }
        },
        shouldEndSession: shouldEndSession
    };
}

function generateResponse(speechletResponse, sessionAttributes){
    return {
        version: "1.0",
        sessionAttributes: sessionAttributes,
        response: speechletResponse
    };
}
